<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">

	<head>
		<meta charset="UTF-8">
		<title>熊猫斯基</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0,minimal-ui">
		<!-- viewport 后面加上 minimal-ui 在safri 体现效果 -->
		<meta name="apple-mobile-web-app-capable" content="yes">
		<!-- iphone safri 全屏 -->
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<!-- iphone safri 状态栏的背景颜色 -->
		<meta name="apple-mobile-web-app-title" content="一文鸡">
		<!-- iphone safri 添加到主屏界面的显示标题 -->
		<meta name="format-detection" content="telphone=no, email=no">
		<!-- 禁止数字识自动别为电话号码 -->
		<meta name="renderer" content="webkit">
		<!-- 启用360浏览器的极速模式(webkit) -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="HandheldFriendly" content="true">
		<!-- 是针对一些老的不识别viewport的浏览器，列如黑莓 -->
		<meta name="MobileOptimized" content="320">
		<!-- 微软的老式浏览器 -->
		<meta http-equiv="Cache-Control" content="no-siteapp">
		<!-- 禁止百度转码 -->
		<meta name="screen-orientation" content="portrait">
		<!-- uc强制竖屏 -->
		<meta name="browsermode" content="application">
		<!-- UC应用模式 -->
		<meta name="full-screen" content="yes">
		<!-- UC强制全屏 -->
		<meta name="x5-orientation" content="portrait">
		<!-- QQ强制竖屏 -->
		<meta name="x5-fullscreen" content="true">
		<!-- QQ强制全屏 -->
		<meta name="x5-page-mode" content="app">
		<!-- QQ应用模式 -->
		<meta name="msapplication-tap-highlight" content="no">
		<meta name="msapplication-TileColor" content="#000">
		<!-- Windows 8 磁贴颜色 -->
		<meta name="msapplication-TileImage" content="icon.png">
		<!-- Windows 8 磁贴图标 -->
		<link rel="Shortcut Icon" href="/Public/fuguiji/favicon.ico">
		<!-- 浏览器tab图标 -->
		<link rel="apple-touch-icon" href="/Public/fuguiji/images/icon.jpg">
		<!-- iPhone 和 iTouch，默认 57x57 像素，必须有 -->
		<link rel="apple-touch-icon" sizes="72x72" href="/Public/fuguiji/images/icon.jpg">
		<!-- iPad，72x72 像素  -->
		<link rel="apple-touch-icon" sizes="114x114" href="/Public/fuguiji/images/icon.jpg">
		<!-- Retina iPhone 和 Retina iTouch，114x114 像素 -->

		<link rel="stylesheet" href="/Public/fuguiji/css/reset.css">
		<link rel="stylesheet" href="/Public/fuguiji/css/style.css">
		<link type="text/css" rel="stylesheet" href="/Public/fuguiji/css/home/popup.css">
		<link type="text/css" rel="stylesheet" href="/Public/fuguiji/css/home/home.css">
		<link type="text/css" rel="stylesheet" href="/Public/fuguiji/css/loign/login.css">
		<link type="text/css" rel="stylesheet" href="/Public/fuguiji/css/zhuanpan.css">
		<style type="text/css">
			.notice_scroll {
				position: relative;
				height: 40px;
				line-height: 40px;
				width: 60%;
				margin-left: 20%;
				margin-top: 10px;
				text-align: center;
				overflow-y: hidden;
				padding: 0 5px;
				background-color: #dff8ff;
				border-radius: 15px;
			}
			
			.notice_scroll li {
				/*position: absolute;*/
				/*top: 0;*/
				height: 40px;
				width: 100%;
				margin: 0 auto;
				/*padding: 5px 0;*/
				font-size: 14px;
				text-align: left;
				text-align-last: left;
			}
			
			.notice_scroll li span {
				display: inline-block;
				max-width: 100%;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
			}
			
			.notice_zhuanp {
				padding: 5px;
				position: relative;
			}
			
			.notice_zhuanp em {
				position: relative;
				z-index: 1;
				background: url(/Public/fuguiji/images/farm/horn.png) no-repeat 0.5rem center;
				background-size: 1.555555rem;
				color: red;
				padding-left: 2.5rem;
				padding-right: 0.27777778rem
			}
		</style>
	</head>

	<body style="background:#dff8ff;overflow-x:hidden;">
		<div class="notice_zhuanp">
			<em>中奖公告：</em>
			<span>222222222</span>
		</div>
		<!--<ul class="notice_scroll">
						<li><span></span></li>
					</ul>-->
		<div class="chicken-page">

			<div class="userBox">
				<img class="bg" src="/Public/fuguiji/images/farm/userBox.png" alt="">
				<section style="line-height: 59px;">
					<div class="headImg" style="background-image: url(&quot;/Public/fuguiji/images/home/portrait/user_icon1.png&quot;);"></div>
					<!--todo: 两个button不要换行-->
					<!--todo: 按钮带提示标志 添加.tips-->
					<!--<button class="market library1"></button>-->
					<!--<button class="friend market library2"></button>-->

					<div class="item clearfix">
						<div class="item-content">
							<p class="name">飞哥</p>
							<!--todo:超出位数限制时 添加.round-->
							<!--熊猫崽-->
							<p class="clm clm-l round">0.26</p>
							<!--熊猫-->
							<p class="clm clm-r round">1084</p>
						</div>
					</div>
				</section>
				<!--<img src="/Public/fuguiji/images/farm/l-vine.png" alt="" class="l-vine vine"> <img src="/Public/fuguiji/images/farm/r-vine.png" alt="" class="r-vine vine">-->
				<em onclick="goBack()" class="btn back"></em> <em onclick="refresh()" class="btn refresh"></em></div>

			<div id="zhuanpan_bg">
				<!-- 代码 开始 -->
				<img src="/Public/fuguiji/images/zhuanpan/1.png" id="shan-img" style="display:none;" />
				<img src="/Public/fuguiji/images/zhuanpan/2.png" id="sorry-img" style="display:none;" />

				<img class="zhuanpan_title_png" src="/Public/fuguiji/images/zhuanpan/zhuanpan_title.png" alt="" />
				<div class="banner">
					<div class="turnplate" style="background-image:url(/Public/fuguiji/images/zhuanpan/turnplate-bg.png);background-size:100% 100%;">
						<canvas class="item" id="wheelcanvas" width="422px" height="422px"></canvas>

						<img class="pointer" src="/Public/fuguiji/images/zhuanpan/turnplate-pointer.png" />
					</div>
					<div class="zhuanpan_menu">
						<span onclick="lotteryRun()"></span>
						<span></span>
					</div>
				</div>
			</div>
		</div>
		<!--<section class="shade" style="display: none;">-->
		<!--请求失败返回的弹层-->
		<div class="login-alert login-alert-msg" id="cleanFriend_alert" style="display:none;">
			<div class="login-alert-board msg-board">
				<div class="context">
					<div class="text">这里是你自定义的内容</div>
				</div>
				<a class="only-confirm"></a>
			</div>
		</div>
		<!--请求成功返回的弹层-->
		<div class="login-alert login-alert-msg" id="returnSucc_alert" style="display:none;">
			<div class="login-alert-board msg-board">
				<div class="context">
					<div class="text">这里是你自定义的内容</div>
				</div>
				<a class="only-confirm"></a>
			</div>
		</div>
		<!--点击转盘弹出，点击确定转盘-->
		<div class="login-alert login-alert-msg" id="confirmZhuanpan_alert" style="display:none;">
			<div class="login-alert-board msg-board">
				<div class="context">
					<div class="text">这里是你自定义的内容</div>
				</div>
				<a class="only-confirm"></a>
			</div>
		</div>
		<!--</section>-->
		<script src="/Public/fuguiji/js/jquery-1.7.2.min.js"></script>
		<script src="/Public/fuguiji/js/echarts.js"></script>
		<script src="/Public/fuguiji/js/function.js"></script>
		<script src="/Public/fuguiji/js/user.js"></script>
		<script src="/Public/fuguiji/js/global.js"></script>
		<script src="/Public/fuguiji/js/home.js"></script>
		<script src="//cdn.bootcss.com/jquery.qrcode/1.0/jquery.qrcode.min.js"></script>
		<script type="text/javascript" src="/Public/fuguiji/js/awardRotate.js"></script>
		<script type="text/javascript">
			//变头像
			if(!(userInfo.icon >= 0 && userInfo.icon < 5)) {
				userInfo.icon = 1;
			}
			if(!userInfo.icon) {
				userInfo.icon = 1;
			}
			$('.headImg').css('background-image', 'url(/Public/fuguiji/images/home/portrait/user_icon' + userInfo.icon + '.png)')
			var noticeList = [];
			getNoticeList();
			var noticeIndex = 0;

			function getNoticeList() {
				$.ajax({
					url: host + "/User/lotteryrecord",
					type: "post",
					data: {
						token: userInfo.token
					},
					dataType: "json",
					success: function(data) {
						if(data.errcode != 10000) {
							//							getGameConfig();
						} else {
							//								gameConfig = data.result;
							noticeList = data.result;
							console.log(noticeList)
							noticeIndex = 0;
						}
					}
				});
			}
			//				var noticeScroll = $('.notice_scroll');
			//				$('.notice_scroll li span').html('恭喜  '+noticeList[noticeIndex++].nickname+'  获得  '+noticeList[noticeIndex].name)
			//				noticeIndex>=noticeList.length&&(noticeIndex = 0);
			setInterval(function() {
				if(noticeList[noticeIndex++]) {
					$('.notice_zhuanp  span').html('恭喜  ' + noticeList[noticeIndex].nickname + '  获得  ' + noticeList[noticeIndex].name)
					noticeIndex >= noticeList.length-1 && (noticeIndex = 0);
				}
				//					console.log($('.notice_scroll li').html());
			}, 3000)
			//				console.log(noticeScroll)
			var turnplate = {
				restaraunts: [], //大转盘奖品名称和id
				colors: [], //大转盘奖品区块对应背景颜色
				outsideRadius: 192, //大转盘外圆的半径
				textRadius: 155, //大转盘奖品位置距离圆心的距离
				insideRadius: 68, //大转盘内圆的半径
				startAngle: 0, //开始角度
				need_num: 5, //抽奖需要的数量

				bRotate: false //false:停止;ture:旋转
			};
			//				console.log(gameConfig)
			//				var gameConfig = null;
			getGameConfig();

			function getGameConfig() {
				$.ajax({
					url: host + "/User/gameconfig",
					type: "post",
					data: {
						token: userInfo.token
					},
					dataType: "json",
					success: function(data) {
						if(data.errcode != 10000) {
							//							getGameConfig();
						} else {
							//								gameConfig = data.result;
							turnplate.need_num = data.result.sysconf.lotter_num
							console.log(turnplate.need_num);
						}
					}
				});
			}
			//旋转转盘 item:奖品位置; txt：提示语;
			var rotateFn = function(item, txt) {
				var angles = item * (360 / turnplate.restaraunts.length) - (360 / (turnplate.restaraunts.length * 2));
				if(angles < 270) {
					angles = 270 - angles;
				} else {
					angles = 360 - angles + 270;
				}
				$('#wheelcanvas').stopRotate();
				$('#wheelcanvas').rotate({
					angle: 0,
					animateTo: angles + 1800,
					duration: 8000,
					callback: function() {
						returnSucc_alert('恭喜获得' + txt);
						turnplate.bRotate = !turnplate.bRotate;
					}
				});
			};

			$.ajax({
				url: host + "/User/lottery",
				type: "post",
				data: {
					token: userInfo.token
				},
				dataType: "json",
				async: false,
				success: function(data) {
					if(data.errcode != 10000) {
						window.location.reload();
					} else {
						turnplate.restaraunts = data.result;
					}
				}
			});

			function lotteryRun() {
				$.ajax({
					url: host + "/User/lotteryRun",
					type: "post",
					data: {
						token: userInfo.token
					},
					dataType: "json",
					async: false,
					success: function(data) {
						if(data.errcode != 10000) {
							turnplate.bRotate = !turnplate.bRotate;
							cleanFriend_alert(data.msg)
						} else {
							$.each(turnplate.restaraunts, function(i, n) {
								if(data.id == n.id) {
									rotateFn(i + 1, n.name);
									console.log(i)
								}
							});
						}
					}
				});
			}

			$(document).ready(function() {
				//处理页面显示业务
				var userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
				if(!userInfo.nickname) userInfo.nickname = "注册会员";
				$('.item-content .name').text(userInfo.nickname);

				if(!userInfo.currency) userInfo.currency = 0;
				$('.item-content .round:eq(0)').text(userInfo.currency);

				if(!userInfo.all_animal) userInfo.all_animal = 0;
				//      $('.item-content .round:eq(1)').text(22);
				$('.item-content .round:eq(1)').text(userInfo.all_animal);
				//动态添加大转盘的奖品与奖品区域背景颜色
				//					turnplate.restaraunts = ["50M免费流量包", "10闪币", "谢谢参与", "5闪币", "10M免费流量包", "20M免费流量包", "20闪币 ", "30M免费流量包", "100M免费流量包", "2闪币"];
				turnplate.colors = ["#FFF4D6", "#FFFFFF", "#FFF4D6", "#FFFFFF", "#FFF4D6", "#FFFFFF", "#FFF4D6", "#FFFFFF", "#FFF4D6", "#FFFFFF"];

				var rotateTimeOut = function() {
					$('#wheelcanvas').rotate({
						angle: 0,
						animateTo: 2160,
						duration: 8000,
						callback: function() {
							alert('网络超时，请检查您的网络设置！');
						}
					});
				};

				$('.pointer').click(function() {
					console.log(turnplate.bRotate)
					if(turnplate.bRotate) return;
					turnplate.bRotate = !turnplate.bRotate;
					confirmZhuanpan_alert('转动一次需要消耗' + turnplate.need_num + '只熊猫')
					//						setInterval(function() {
					//							var item = rnd(1, turnplate.restaraunts.length);
					//							item = 5
					//							rotateFn(item, turnplate.restaraunts[item - 1]);
					//						}, 4000)
					//获取随机数(奖品个数范围内)
					//					var item = rnd(1, turnplate.restaraunts.length);
					//					item = 4
					//奖品数量等于10,指针落在对应奖品区域的中心角度[252, 216, 180, 144, 108, 72, 36, 360, 324, 288]
					//					rotateFn(item, turnplate.restaraunts[item - 1]);
				});

			});

			$('body').delegate('#confirmZhuanpan_alert .msg-board .only-confirm', 'click', function() {
				lotteryRun();
			})

			function rnd(n, m) {
				var random = Math.floor(Math.random() * (m - n + 1) + n);
				return random;

			}

			//页面所有元素加载完毕后执行drawRouletteWheel()方法对转盘进行渲染
			window.onload = function() {
				drawRouletteWheel();
			};

			function goBack() {
				history.go(-1);
			}

			function refresh() {
				window.location.reload();
			}

			function drawRouletteWheel() {
				var canvas = document.getElementById("wheelcanvas");
				if(canvas.getContext) {
					//根据奖品个数计算圆周角度
					var arc = Math.PI / (turnplate.restaraunts.length / 2);
					var ctx = canvas.getContext("2d");
					//在给定矩形内清空一个矩形
					ctx.clearRect(0, 0, 422, 422);
					//strokeStyle 属性设置或返回用于笔触的颜色、渐变或模式  
					ctx.strokeStyle = "#FFBE04";
					//font 属性设置或返回画布上文本内容的当前字体属性
					ctx.font = '16px Microsoft YaHei';
					for(var i = 0; i < turnplate.restaraunts.length; i++) {
						var angle = turnplate.startAngle + i * arc;
						ctx.fillStyle = turnplate.colors[i];
						ctx.beginPath();
						//arc(x,y,r,起始角,结束角,绘制方向) 方法创建弧/曲线（用于创建圆或部分圆）    
						ctx.arc(211, 211, turnplate.outsideRadius, angle, angle + arc, false);
						ctx.arc(211, 211, turnplate.insideRadius, angle + arc, angle, true);
						ctx.stroke();
						ctx.fill();
						//锁画布(为了保存之前的画布状态)
						ctx.save();

						//----绘制奖品开始----
						ctx.fillStyle = "#E5302F";
						var text = turnplate.restaraunts[i].name;
						var line_height = 17;
						//translate方法重新映射画布上的 (0,0) 位置
						ctx.translate(211 + Math.cos(angle + arc / 2) * turnplate.textRadius, 211 + Math.sin(angle + arc / 2) * turnplate.textRadius);

						//rotate方法旋转当前的绘图
						ctx.rotate(angle + arc / 2 + Math.PI / 2);

						/** 下面代码根据奖品类型、奖品名称长度渲染不同效果，如字体、颜色、图片效果。(具体根据实际情况改变) **/
						if(text.indexOf("M") > 0) { //流量包
							var texts = text.split("M");
							for(var j = 0; j < texts.length; j++) {
								ctx.font = j == 0 ? 'bold 20px Microsoft YaHei' : '16px Microsoft YaHei';
								if(j == 0) {
									ctx.fillText(texts[j] + "M", -ctx.measureText(texts[j] + "M").width / 2, j * line_height);
								} else {
									ctx.fillText(texts[j], -ctx.measureText(texts[j]).width / 2, j * line_height);
								}
							}
						} else if(text.indexOf("M") == -1 && text.length > 6) { //奖品名称长度超过一定范围 
							text = text.substring(0, 6) + "||" + text.substring(6);
							var texts = text.split("||");
							for(var j = 0; j < texts.length; j++) {
								ctx.fillText(texts[j], -ctx.measureText(texts[j]).width / 2, j * line_height);
							}
						} else {
							//在画布上绘制填色的文本。文本的默认颜色是黑色
							//measureText()方法返回包含一个对象，该对象包含以像素计的指定字体宽度
							ctx.fillText(text, -ctx.measureText(text).width / 2, 0);
						}

						//添加对应图标
						if(text.indexOf("闪币") > 0) {
							var img = document.getElementById("shan-img");
							img.onload = function() {
								ctx.drawImage(img, -15, 10);
							};
							ctx.drawImage(img, -15, 10);
						} else if(text.indexOf("谢谢参与") >= 0) {
							var img = document.getElementById("sorry-img");
							img.onload = function() {
								ctx.drawImage(img, -15, 10);
							};
							ctx.drawImage(img, -15, 10);
						}
						//把当前画布返回（调整）到上一个save()状态之前 
						ctx.restore();
						//----绘制奖品结束----
					}
				}
			}

			function confirmZhuanpan_alert(text) {
				//					$('.shade').show();
				$('#confirmZhuanpan_alert').show();
				$('#confirmZhuanpan_alert').css('z-index', '110');
				$('#confirmZhuanpan_alert').css('top', '0');
				console.log($('#confirmZhuanpan_alert .context .text').html(text))
			}

			function returnSucc_alert(text) {
				//					$('.shade').show();
				$('#returnSucc_alert').show();
				$('#returnSucc_alert').css('z-index', '110');
				$('#returnSucc_alert').css('top', '0');
				console.log($('#returnSucc_alert .context .text').html(text))
			}

			function cleanFriend_alert(text) {
				$('.shade').show();
				$('#cleanFriend_alert').show();
				$('#cleanFriend_alert').css('z-index', '110');
				$('#cleanFriend_alert').css('top', '0');
				console.log($('#cleanFriend_alert .context .text').html(text))
			}
		</script>
	</body>

</html>