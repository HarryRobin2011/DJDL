<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">

	<head>
		<meta charset="UTF-8">
		<title>熊猫斯基</title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0,minimal-ui">
		<!-- viewport 后面加上 minimal-ui 在safri 体现效果 -->
		<meta name="apple-mobile-web-app-capable" content="yes">
		<!-- iphone safri 全屏 -->
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<!-- iphone safri 状态栏的背景颜色 -->
		<meta name="apple-mobile-web-app-title" content="一文鸡">
		<!-- iphone safri 添加到主屏界面的显示标题 -->
		<meta name="format-detection" content="telphone=no, email=no">
		<!-- 禁止数字识自动别为电话号码 -->
		<meta name="renderer" content="webkit">
		<!-- 启用360浏览器的极速模式(webkit) -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="HandheldFriendly" content="true">
		<!-- 是针对一些老的不识别viewport的浏览器，列如黑莓 -->
		<meta name="MobileOptimized" content="320">
		<!-- 微软的老式浏览器 -->
		<meta http-equiv="Cache-Control" content="no-siteapp">
		<!-- 禁止百度转码 -->
		<meta name="screen-orientation" content="portrait">
		<!-- uc强制竖屏 -->
		<meta name="browsermode" content="application">
		<!-- UC应用模式 -->
		<meta name="full-screen" content="yes">
		<!-- UC强制全屏 -->
		<meta name="x5-orientation" content="portrait">
		<!-- QQ强制竖屏 -->
		<meta name="x5-fullscreen" content="true">
		<!-- QQ强制全屏 -->
		<meta name="x5-page-mode" content="app">
		<!-- QQ应用模式 -->
		<meta name="msapplication-tap-highlight" content="no">
		<meta name="msapplication-TileColor" content="#000">
		<!-- Windows 8 磁贴颜色 -->
		<meta name="msapplication-TileImage" content="icon.png">
		<!-- Windows 8 磁贴图标 -->
		<link rel="Shortcut Icon" href="/Public/fuguiji/favicon.ico">
		<!-- 浏览器tab图标 -->
		<link rel="apple-touch-icon" href="/Public/fuguiji/images/icon.jpg">
		<!-- iPhone 和 iTouch，默认 57x57 像素，必须有 -->
		<link rel="apple-touch-icon" sizes="72x72" href="/Public/fuguiji/images/icon.jpg">
		<!-- iPad，72x72 像素  -->
		<link rel="apple-touch-icon" sizes="114x114" href="/Public/fuguiji/images/icon.jpg">
		<!-- Retina iPhone 和 Retina iTouch，114x114 像素 -->
		<link rel="stylesheet" href="/Public/fuguiji/css/reset.css">
		<link rel="stylesheet" href="/Public/fuguiji/css/style.css">
		<link type="text/css" rel="stylesheet" href="/Public/fuguiji/css/loign/login.css">
		<link type="text/css" rel="stylesheet" href="/Public/fuguiji/css/records/records.css">
	</head>

	<body>
		<div class="chicken-page">
			<!--滚动公告-->
			<div class="notice">
				<em>(点我查看完整公告)</em>
				<p>
					<span>&nbsp;</span>
				</p>
			</div>

			<div class="userBox">
				<img class="bg" src="/Public/fuguiji/images/farm/userBox.png" alt="">
				<section>
					<div class="headImg" style="background-image: url('/Public/fuguiji/images/home/portrait/portrait-man.png')"></div>
					<div class="item clearfix" style="padding-right: 20%;">
						<div class="item-content">
							<p class="name">&nbsp;</p>
							<p class="clm clm-l">0</p>
							<p class="clm clm-r">0</p>
						</div>
					</div>
				</section>
				<!--<img src="/Public/fuguiji/images/farm/l-vine.png" alt="" class="l-vine vine">-->
				<!--<img src="/Public/fuguiji/images/farm/r-vine.png" alt="" class="r-vine vine">-->
				<em class="btn back"></em>
				<em class="btn refresh"></em>
			</div>

			<div class="fieldBox">
				<div class="middleware">
					<ul class="field clearfix">
						<!--<img class="floor-bg" src="/Public/fuguiji/images/farm/floor.png" alt="">-->
						<!--todo li上加  等级：lv1，lv2，lv3，lvMax-->
						<!--todo Bubble上加egg熊猫崽气泡-->
						<li class="green" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="green" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="green" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="green" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="green" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="green" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="green" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="green" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="green" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="green" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="gold" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="gold" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="gold" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="gold" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
						<li class="gold" style="height:100px">
							<section class="Bubble"><i></i></section>
						</li>
					</ul>
				</div>
			</div>

			<div class="desktop">
				<img src="/Public/fuguiji/images/farm/desktop.png" alt="" style="position: static">
				<button class="clean"></button>
			</div>

			<div class="dog" style="display: none;top: 75%;">
				<div>
					<img class="dog_lev_icon" src="/Public/fuguiji/images/farm/dog/01.gif" alt="">
				</div>
			</div>

		</div>
		<!--todo: 打扫动画时 添加.showClean-->
			<div class="login-alert login-alert-msg" id="cleanFriend_alert" style="display:none;">
				<div class="login-alert-board msg-board">
					<div class="context">
						<div class="text">这里是你自定义的内容</div>
					</div>
					<a class="only-confirm"></a>
				</div>
			</div>
		<section class="shade" style="display: none">
			<!--todo: 打扫结果-->
			<div class="content min cleanCheck" style="display: none">
				<div class="flex-box">
					<div class="f-l"></div>
					<div class="flex"></div>
					<div class="f-r"></div>
				</div>
				<p>恭喜~打扫获得<br><em>20只</em><i class="ico-egg"></i></p>
				<button class="yellowBtn"><span>确认</span></button>
				<i class="bottom"></i>
			</div>

			<!--todo:打扫动画-->
			<div class="cleanAnimation" style="display: none"></div>

			<!--todo: 公告弹窗-->
			<div class="content notice" style="display: none">
				<div class="title">
					<img src="/Public/fuguiji/images/window/title-bg.png" class="title-c" alt="">
					<img src="/Public/fuguiji/images/window/left_y.png" class="title-l" alt="">
					<img src="/Public/fuguiji/images/window/right_y.png" class="title-r" alt="">
					<em>公告</em>
				</div>
				<i class="close"></i><i class="bottom"></i>
				<ul class="show">
				</ul>
			</div>
		</section>

		<script src="/Public/fuguiji/js/jquery-1.7.2.min.js"></script>
		<!--<audio src="/Public/fuguiji/music/bg.mp3" preload="" loop></audio>-->
		<script src="/Public/fuguiji/js/function.js"></script>
		<script src="/Public/fuguiji/js/global.js"></script>
		<script src="/Public/fuguiji/js/record.js"></script>
		<script src="/Public/fuguiji/js/jquery-1.7.2.min.js"></script>
		<script>console.log()
$('.desktop .clean').click(function() {
	var id = $(this).attr('data-id');
	if(!id) {
		return;
	}
	$.ajax({
		url: host + "/User/clearnfriend",
		type: "post",
		data: {
			token: userInfo.token,
			toUserId: id
		},
		dataType: "json",
		success: function(data) {
			console.log(data)
			if(data.errcode == 10000) {
				cleanFriend_alert(data.currency);
				//							window.location.reload();
			} else {
				returnAlert(data.msg);
			}
		},
		error: function(data) {}
	});
});
$('.cleanCheck .yellowBtn').click(function() {
	window.location.reload();
})

function cleanFriend_alert(text) {
	$('.shade').show();
	$('.cleanCheck').show();
	console.log($('.shade .cleanCheck em').html(text + '只'))
}
function returnAlert(text){
//		$('.shade').show();
		$('#cleanFriend_alert').show();
		$('#cleanFriend_alert').css('z-index','110');
		$('#cleanFriend_alert').css('top','0');
		console.log($('#cleanFriend_alert .context .text').html(text))
}
var friendInfo = {};
$.ajax({
	url: host + "/User/getfriendsfarm",
	type: "post",
	data: {
		token: userInfo.token,
		friendid: window.location.href.split('id=')[1]
	},
	dataType: "json",
	success: function(data) {
		console.log(data)
		if(data.errcode == 10000) {
			friendInfo = data.result[0];
			addChicken(friendInfo.friend_farm)
			//delete
			//						friendInfo.friend_usermsg.egg_parent_status = 1
			if(friendInfo.friend_usermsg.egg_parent_status == 1) {
				$('.desktop .clean').removeClass('cur');
				$('.desktop .clean').attr('data-id', friendInfo.friendid);

			}
			//						console.log(friendInfo.friend_usermsg.egg_parent_status)
			if(friendInfo.friend_usermsg.egg_parent_status == 2) {
				$('.desktop .clean').addClass('cur');
			}
			console.log(friendInfo.friend_usermsg)
			$('.userBox .name').html(friendInfo.friend_usermsg.nickname);
			$('.userBox .clm-l').html(friendInfo.friend_usermsg.currency);
			$('.userBox .clm-r').html(friendInfo.friend_usermsg.all_animal);
			//栅栏的等级
//			friendInfo.friend_usermsg.enclosure_lev=4
			$('.field li').each(function(i, n) {
				if($(n).find(".chicken-box").size()) {
					$(n).addClass('lv' + friendInfo.friend_usermsg.enclosure_lev)
				}
			})
			//狗的等级
//			friendInfo.friend_usermsg.dog_lev=3
//			console.log($('.dog .dog_lev_icon')[0].currentSrc)
			if(friendInfo.friend_usermsg.dog_lev) {
								$('.dog').show();
								$('.dog .dog_lev_icon').attr('src', $('.dog .dog_lev_icon')[0].currentSrc.slice(0, -5) + friendInfo.friend_usermsg.dog_lev + '.gif')
							}
			//					alert('打扫成功')
			//					window.location.reload();
		} else {
			returnAlert(data.msg);
		}
	},
	error: function(data) {}
});

var field_open_ed = {
	//绿地
	field0: null,
	field1: null,
	field2: null,
	field3: null,
	field4: null,
	field5: null,
	field6: null,
	field7: null,
	field8: null,
	field9: null,
	//金地
	field10: null,
	field11: null,
	field12: null,
	field13: null,
	field14: null,
};

function addChicken(c) {
	console.log(c)
	var field_open_num = { //开地的数量
			green: 0,
			gold: 10
		},
		level = 0;
	//				console.log(chicken)
	for(var i = 0; i < c.length; i++) {
		//					console.log(c[i])
		var status = c[i].status;
		var txt = "";
		var cl = "";
		var li_index;
		var farmAnimalsNum = parseInt(c[i].add_num)+parseInt(c[i].base_num);
		var runGifNum = 1;
		if(c[i].type == '1') {
			li_index = field_open_num.green++;
			runGifNum = Math.ceil(farmAnimalsNum/1000);
		} else {
			li_index = field_open_num.gold++;
			runGifNum = Math.ceil(farmAnimalsNum/10000);
		}
		field_open_ed['field' + li_index] = c[i];
		while($(".field li").eq(li_index).find(".chicken-box").size() > 0) {
			li_index = Math.floor(Math.random() * c.length); //可均衡获取0到9的随机整数
		}
		if(c[i].egg_status == 1) {
			$(".field li").eq(li_index).find('.Bubble').children().css('opacity', 1);
		}
		if(c[i].egg_status == 2) {
			$(".field li").eq(li_index).find('.Bubble').children().css('opacity', 0);
		}
		$(".field li").eq(li_index).addClass('');
		console.log(c)
		$(".field li").eq(li_index).append('<img  style="width:100%;" class="bg chicken-box" src="/Public/fuguiji/images/farm/run/run_gif_'+runGifNum+'.gif" alt="">');
//		$(".field li").eq(li_index).append('<div class="chicken-box run-move"  style="animation-delay:  ' + c[i].delay + 's; top: ' + c[i].top + 'rem;" id-name=' + c[i].name + '><i class="chicken-run" style="animation-delay:  ' + c[i].delay + 's;"></i><span class="txt ' + cl + '">' + txt + '<span></div>');

	}
}
var currentField = null;
$('.fieldBox .field li').click(function() {
	console.log(this)
	var me = this;
	//栅栏的等级
	var fieldIndex = $.inArray(me, $('.field li'));
	console.log(fieldIndex)
	currentField = field_open_ed['field' + fieldIndex];
	if($(me).find('.chicken-box').length && !$(me).hasClass('canOpen')) {
		console.log(field_open_ed['field' + fieldIndex])
		console.log(currentField.add_num)
		var showboxHtml = '<div class="clickShowBox show" style="top: 0px;"><p><b>小熊猫总数:</b><em>' +
			(parseFloat(currentField.add_num) + parseFloat(currentField.base_num)) +
			'</em></p><p><b>本日产崽:</b><em>' +
			currentField.egg_rate + '</em></p><p><b>历史产崽:</b><em>' +
			currentField.egg_allrate + '</em></p><i></i></div>';
		$($(me).children()[0]).append(showboxHtml);
		$('body').append('<section class="clickShowBox-shade"></section>');
	}
})
$('body').delegate('.clickShowBox-shade', 'click', function() {
	$(this).remove();
	$('.fieldBox .clickShowBox').remove();
});
$('.userBox .back').click(function() {
	history.go(-1);
});
$('.userBox .refresh').click(function() {
	window.location.reload();
});
//			console.log($('.userBox .back'))</script>
	</body>

</html>